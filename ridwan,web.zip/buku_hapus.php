<?php
// Pastikan koneksi database sudah terhubung di file utama (index.php)
// Atau aktifkan baris di bawah jika file ini diakses secara mandiri:
// include 'koneksi.php';

// 1. Cek apakah parameter ID buku tersedia di URL
if (isset($_GET['id'])) {
    $id_buku = $_GET['id'];

    // 2. Amankan data dari potensi SQL Injection
    $id_buku = mysqli_real_escape_string($koneksi, $id_buku);

    // [Opsional / Opsional Aman]: Cek dulu apakah buku sedang dipinjam
    // Jika buku masih berstatus dipinjam, kita bisa mencegahnya dihapus agar database tidak error/patah relasi.
    $cek_pinjam = mysqli_query($koneksi, "SELECT * FROM peminjaman WHERE id_buku = '$id_buku' AND status_peminjaman = 'dipinjam'");
    
    if (mysqli_num_rows($cek_pinjam) > 0) {
        // Jika buku sedang dipinjam, batalkan penghapusan dan beri peringatan
        echo "<script>
                alert('Gagal menghapus! Buku ini sedang dipinjam oleh user.');
                window.location.href = '?page=buku';
              </script>";
        exit();
    }

    // 3. Buat query SQL untuk menghapus data buku berdasarkan ID
    $sql = "DELETE FROM buku WHERE id_buku = '$id_buku'";
    $query = mysqli_query($koneksi, $sql);

    // 4. Periksa apakah proses hapus berhasil atau gagal
    if ($query) {
        // Jika berhasil, redirect kembali ke halaman data buku dengan pesan sukses
        echo "<script>
                alert('Data buku berhasil dihapus!');
                window.location.href = '?page=buku';
              </script>";
    } else {
        // Jika gagal (misal karena terkait Foreign Key di tabel lain), tampilkan pesan error
        echo "<script>
                alert('Gagal menghapus buku: " . mysqli_error($koneksi) . "');
                window.location.href = '?page=buku';
              </script>";
    }
} else {
    // Jika parameter ID tidak ada di URL, langsung lempar balik ke halaman data buku
    header("Location: ?page=buku");
    exit();
}
?>