<?php
// Menangkap ID dari URL
$id = $_GET['id'];

// Proses saat tombol simpan ditekan
if(isset($_POST['simpan'])) {
    $ulasan = $_POST['ulasan'];
    $rating = $_POST['rating'];

    // Query UPDATE disesuaikan dengan nama tabel (ulasan) dan kolom ID (id_ulasan)
    $query = mysqli_query($koneksi, "UPDATE ulasan SET ulasan = '$ulasan', rating = '$rating' WHERE id_ulasan = '$id'");

    if($query) {
        echo '<script>alert("Ubah ulasan berhasil."); location.href="?page=ulasan";</script>';
    } else {
        echo '<script>alert("Ubah ulasan gagal.");</script>';
    }
}

// Menarik data berdasarkan id_ulasan
$query_tampil = mysqli_query($koneksi, "SELECT * FROM ulasan WHERE id_ulasan = '$id'");
$data = mysqli_fetch_array($query_tampil);
?>

<h1 class="mt-4">Ubah Ulasan</h1>
<div class="card">
    <div class="card-body">
        <form method="post">
            <div class="row mb-3">
                <div class="col-md-2">Ulasan</div>
                <div class="col-md-8">
                    <!-- Menampilkan data ulasan lama -->
                    <textarea name="ulasan" rows="5" class="form-control"><?php echo $data['ulasan']; ?></textarea>
                </div>
            </div>
            
            <div class="row mb-3">
                <div class="col-md-2">Rating (1-10)</div>
                <div class="col-md-8">
                    <select name="rating" class="form-control">
                        <?php
                        // Menampilkan data rating lama
                        for($i = 1; $i <= 10; $i++) {
                            $selected = ($data['rating'] == $i) ? 'selected' : '';
                            echo "<option value='$i' $selected>$i</option>";
                        }
                        ?>
                    </select>
                </div>
            </div>

            <div class="row">
                <div class="col-md-2"></div>
                <div class="col-md-8">
                    <button type="submit" class="btn btn-primary" name="simpan">Simpan</button>
                    <button type="reset" class="btn btn-secondary">Reset</button>
                    <a href="?page=ulasan" class="btn btn-danger">Kembali</a>
                </div>
            </div>
        </form>
    </div>
</div>