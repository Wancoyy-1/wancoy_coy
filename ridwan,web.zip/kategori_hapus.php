<?php
$id = $_GET['id'];
$query = mysqli_query($koneksi, "DELETE FROM kategori WHERE id_kategori=$id");
?>
<script>Swal.fire({title: "Successfully", text: "Kategori Berhasil dihapus!", icon: "success"}).then(() => {setTimeout(() => {location.href = "?page=kategori";}, 500);});</script>