<?php
// Pastikan file koneksi database sudah terhubung
// include 'koneksi.php';

// 1. Cek apakah parameter ID ulasan tersedia di URL
if (isset($_GET['id'])) {
    $id_ulasan = $_GET['id'];

    // 2. Amankan data dari potensi SQL Injection
    $id_ulasan = mysqli_real_escape_string($koneksi, $id_ulasan);

    // 3. Buat query SQL untuk menghapus data ulasan berdasarkan ID
    $sql = "DELETE FROM ulasan WHERE id_ulasan = '$id_ulasan'";
    $query = mysqli_query($koneksi, $sql);

    // 4. Periksa apakah proses hapus berhasil atau gagal
    if ($query) {
        // Jika berhasil, redirect kembali ke halaman daftar ulasan dengan pesan sukses
        echo "<script>
                alert('Ulasan berhasil dihapus!');
                window.location.href = '?page=ulasan';
              </script>";
    } else {
        // Jika gagal, tampilkan pesan error dari database
        echo "<script>
                alert('Gagal menghapus ulasan: " . mysqli_error($koneksi) . "');
                window.location.href = '?page=ulasan';
              </script>";
    }
} else {
    // Jika parameter ID tidak ada di URL, langsung lempar balik ke halaman ulasan
    header("Location: ?page=ulasan");
    exit();
}
?>